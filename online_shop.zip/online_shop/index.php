<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Shop</title>
</head>
<body>
    <h1>Welcome to the Online Shop</h1>
    <p><a href="Views/login.php">Login</a></p>
    <p><a href="Views/home.php">View Products</a></p>
</body>
</html>

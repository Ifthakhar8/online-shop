<?php
session_start();
require_once('../Models/alldb.php');


if (!isset($_SESSION['user_id'])) {
    header('location:login.php');
    exit();
}

$products = showProducts();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home - Online Shop</title>
    <style>
        
        .product {
            border: 1px solid #ccc;
            padding: 16px;
            margin: 16px;
        }
        .product img {
            max-width: 150px;
            height: auto;
        }
    </style>
</head>
<body>

    <h1>Welcome to the Online Shop</h1>
    <a href="logout.php">Logout</a>

    <h2>Products</h2>
    <div class="products">
        <?php 
        if ($products->num_rows > 0) {
            while($product = $products->fetch_assoc()) {
                echo '<div class="product">';
                echo '<h3>' . htmlspecialchars($product['name']) . '</h3>';
                echo '<img src="' . htmlspecialchars($product['image_url']) . '" alt="' . htmlspecialchars($product['name']) . '">';
                echo '<p>' . htmlspecialchars($product['description']) . '</p>';
                echo '<p>Price: $' . htmlspecialchars($product['price']) . '</p>';
                echo '</div>';
            }
        } else {
            echo '<p>No products available.</p>';
        }
        ?>
    </div>

</body>
</html>

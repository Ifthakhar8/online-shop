<?php
session_start();
require_once('../Models/alldb.php');


if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    $_SESSION['error'] = "Access denied.";
    header('location:login.php');
    exit();
}

$customers = showCustomers();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin - Customer Details</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>

    <h1>Admin Dashboard</h1>
    <a href="logout.php">Logout</a>

    <h2>Customer Details</h2>
    <?php 
    if ($customers->num_rows > 0) {
        echo '<table>';
        echo '<tr>
                <th>Customer ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
              </tr>';
        while($customer = $customers->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($customer['customer_id']) . '</td>';
            echo '<td>' . htmlspecialchars($customer['first_name']) . '</td>';
            echo '<td>' . htmlspecialchars($customer['last_name']) . '</td>';
            echo '<td>' . htmlspecialchars($customer['email']) . '</td>';
            
            
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo '<p>No customer details available.</p>';
    }
    ?>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Online Shop</title>
</head>
<body>

    <h1>Login Page</h1>

    <form method="post" action="../Controllers/loginCheckController.php">
        ID:<input type="text" name="id" required><br>
        Pass: <input type="password" name="pass" required><br>
        <?php 
        session_start();
        if(isset($_SESSION['error'])){
            echo '<p style="color:red;">' . htmlspecialchars($_SESSION['error']) . '</p>';
            unset($_SESSION['error']);
        }
        ?>
        <br>
        <button type="submit" name="submit">Login</button>
    </form>

</body>
</html>

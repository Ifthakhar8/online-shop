<?php
function getConnection()
{
    $serverName = "localhost";
    $userName = "root";
    $password = "";
    $dbName = "abdd";
    $conn = new mysqli($serverName, $userName, $password, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}
?>

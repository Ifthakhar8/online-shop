<?php
require_once('db.php');


function auth($id, $pass)
{
    $conn = getConnection();
    $stmt = $conn->prepare("SELECT * FROM ab WHERE id = ? AND pass = ?");
    $stmt->bind_param("ss", $id, $pass);
    $stmt->execute();
    $status = $stmt->get_result();
    $conn->close();
    return $status;
}


function showUsers()
{
    $conn = getConnection();
    $sql = "SELECT * FROM ab";
    $res = $conn->query($sql);
    $conn->close();
    return $res;
}


function showProducts()
{
    $conn = getConnection();
    $sql = "SELECT * FROM products";
    $res = $conn->query($sql);
    $conn->close();
    return $res;
}


function showCustomers()
{
    $conn = getConnection();
    $sql = "SELECT c.*, u.id, u.pass FROM customers c JOIN ab u ON c.user_id = u.user_id";
    $res = $conn->query($sql);
    $conn->close();
    return $res;
}
?>

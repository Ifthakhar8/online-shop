<?php
session_start();
require_once('../Models/alldb.php');

if(isset($_POST['submit']))
{
    $id = $_POST['id'];
    $pass = $_POST['pass'];

    if(empty($id) || empty($pass))
    {
        $_SESSION['error'] = "Please fill up the form first";
        header('location:../Views/login.php');
    }
    else
    {
        $res = auth($id, $pass);
        if(mysqli_num_rows($res) == 1)
        {
            $user = $res->fetch_assoc();
            $_SESSION['user_id'] = $user['user_id']; 
            $_SESSION['user_role'] = $user['role']; 

            if($user['role'] === 'admin') {
                header('location:adminController.php');
            } else {
                header('location:homeController.php');
            }
        }
        else
        {
            $_SESSION['error'] = "Invalid User";
            header('location:../Views/login.php');
        }
    }
}
?>

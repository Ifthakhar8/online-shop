<?php
session_start();
require_once('../Models/alldb.php');


if (!isset($_SESSION['user_id'])) {
    header('location:login.php');
    exit();
}


$res1 = showProducts();
if ($res1) {
    header('location:../Views/home.php');
} else {
    $_SESSION['error'] = "Failed to fetch products.";
    header('location:../Views/home.php');
}
?>

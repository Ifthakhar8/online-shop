<?php
session_start();
require_once('../Models/alldb.php');


if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    $_SESSION['error'] = "অ্যাক্সেস নিষিদ্ধ।";
    header('location:../Views/login.php');
    exit();
}


$res = showCustomers();
?>
